<html>
    <head>
        <title><?php echo $title;?></title>
        <body>
    </head>